//
//  osahonTests.swift
//  osahonTests
//
//  Created by mav on 01/01/2025.
//

import Testing
@testable import osahon

struct osahonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
