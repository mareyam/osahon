
import SwiftUI

@main
struct osahonApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
//            PythonIntegrationView()
            Tabs()
        }
    }
}
